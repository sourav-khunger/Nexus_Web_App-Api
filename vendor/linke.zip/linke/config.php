<?php
require_once 'vendor/autoload.php';
 
$config = [
    'callback' => 'https://doozycodsys.com/NEXUS/linke/index.php',
    'keys'     => [
                    'id' => '78fg1ed7xkb0z2',
                    'secret' => 'npYmtpQjDbxseXjA'
                ],
    'scope'    => 'r_liteprofile r_emailaddress',
];
 
$adapter = new Hybridauth\Provider\LinkedIn( $config );